<?php
declare(strict_types=1);

/**
 * Ambil SKU dari aplikasi Inventory.
 * Data produk dibaca READ-ONLY dari database aplikasi Inventory; halaman ini
 * menambahkan SKU yang dicentang (beserta jumlahnya) ke daftar di halaman utama.
 */

require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/layout.php';
require_login();

$list = list_get();
$error = null;
$flashMsg = flash();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $picked = $_POST['pick'] ?? [];
    if (!is_array($picked)) $picked = [];
    $qtys = $_POST['qty'] ?? [];
    if (!is_array($qtys)) $qtys = [];

    $added = [];
    foreach ($picked as $sku) {
        $sku = trim((string)$sku);
        if ($sku === '') continue;
        $qty = (int)($qtys[$sku] ?? 1);
        if ($qty < 1) $qty = 1;
        if ($qty > MAX_COPIES) $qty = MAX_COPIES;
        for ($i = 0; $i < $qty; $i++) $added[] = $sku;
    }

    if (!$added) {
        $error = 'Belum ada produk yang dicentang.';
    } else {
        list_add($added);
        $_SESSION['qrl_show'] = false;
        flash(count($picked) . ' SKU ditambahkan ke daftar (' . count($added) . ' baris).');
        redirect('index.php');
    }
}

$inventoryMissing = !inventory_exists();
$q = trim((string)($_GET['q'] ?? ''));
$brandId = (int)($_GET['brand'] ?? 0);
$showInactive = !empty($_GET['all']);

$rows = [];
$brands = [];
$totalProducts = 0;
if (!$inventoryMissing) {
    try {
        $where = [];
        $params = [];
        if ($q !== '') {
            $where[] = '(p.sku LIKE ? OR p.category LIKE ?)';
            $params[] = '%' . $q . '%';
            $params[] = '%' . $q . '%';
        }
        if ($brandId > 0) {
            $where[] = 'p.brand_id = ?';
            $params[] = $brandId;
        }
        if (!$showInactive) $where[] = 'p.active = 1';
        $sql = 'SELECT p.id, p.sku, p.category, p.unit, p.sell_price, p.stock_qty, p.active, b.name AS brand'
            . ' FROM products p LEFT JOIN brands b ON b.id = p.brand_id'
            . ($where ? ' WHERE ' . implode(' AND ', $where) : '')
            . ' ORDER BY (b.name IS NULL), b.name, p.sku LIMIT 500';
        $rows = inv_all($sql, $params);
        $brands = inv_all('SELECT id, name FROM brands ORDER BY name');
        $totalProducts = (int)(inv_one('SELECT COUNT(*) AS c FROM products')['c'] ?? 0);
    } catch (Throwable $e) {
        $error = 'Gagal membaca daftar produk dari aplikasi Inventory.';
    }
}

$selectedCount = count($list);

page_start('Ambil dari Inventory');
?>
<div class="wrap">

  <div class="page-head">
    <h1>Ambil dari Inventory</h1>
    <p class="muted">Centang produk yang mau dicetak labelnya, isi jumlah baris label per SKU, lalu tambahkan
      ke daftar. Daftar SKU dipakai di halaman <a href="index.php">Buat label QR</a>.</p>
  </div>

  <?php if ($flashMsg): ?>
    <?= notice_box((string)$flashMsg['msg'], (string)$flashMsg['type']) ?>
  <?php endif; ?>
  <?php if ($error !== null): ?>
    <?= notice_box($error) ?>
  <?php endif; ?>
  <?php if ($inventoryMissing): ?>
    <?= notice_box('Berkas database aplikasi Inventory tidak ditemukan, jadi daftar produk tidak bisa ditampilkan. '
        . 'SKU masih bisa diketik manual di halaman utama.', 'warn') ?>
  <?php else: ?>

  <form class="card filter-card" method="get" action="pick.php">
    <div class="form-row">
      <label class="field field-grow">
        <span>Cari SKU / kategori</span>
        <input type="text" name="q" value="<?= h($q) ?>" placeholder="mis. JK atau KAOS">
      </label>
      <label class="field">
        <span>Brand</span>
        <select name="brand">
          <option value="0">Semua brand</option>
          <?php foreach ($brands as $b): ?>
            <option value="<?= (int)$b['id'] ?>" <?= $brandId === (int)$b['id'] ? 'selected' : '' ?>><?= h((string)$b['name']) ?></option>
          <?php endforeach; ?>
        </select>
      </label>
      <label class="check check-mid">
        <input type="checkbox" name="all" value="1" <?= $showInactive ? 'checked' : '' ?>>
        <span>Tampilkan produk nonaktif</span>
      </label>
      <button class="btn btn-ghost" type="submit">Cari</button>
    </div>
  </form>

  <form method="post" action="pick.php">
    <?= csrf_field() ?>
    <div class="card table-card">
      <div class="table-head">
        <label class="check">
          <input type="checkbox" id="pick-all">
          <span>Pilih semua yang tampil</span>
        </label>
        <span class="muted small"><?= count($rows) ?> produk ditampilkan · <?= $totalProducts ?> total di Inventory</span>
      </div>
      <div class="table-wrap">
        <table class="table" id="pick-table">
          <thead>
            <tr>
              <th class="col-check"></th>
              <th>SKU</th>
              <th>Brand</th>
              <th>Kategori</th>
              <th>Satuan</th>
              <th class="col-num">Stok</th>
              <th class="col-qty">Jumlah label</th>
            </tr>
          </thead>
          <tbody>
          <?php if (!$rows): ?>
            <tr><td colspan="7" class="muted">Tidak ada produk yang cocok dengan filter.</td></tr>
          <?php endif; ?>
          <?php foreach ($rows as $r): ?>
            <tr<?= (int)$r['active'] === 1 ? '' : ' class="row-inactive"' ?>>
              <td class="col-check">
                <input type="checkbox" name="pick[]" value="<?= h((string)$r['sku']) ?>"
                       aria-label="Pilih <?= h((string)$r['sku']) ?>">
              </td>
              <td class="mono"><?= h((string)$r['sku']) ?></td>
              <td><?= h((string)($r['brand'] ?? '—')) ?></td>
              <td><?= h((string)($r['category'] ?? '—')) ?></td>
              <td><?= h((string)($r['unit'] ?? '—')) ?></td>
              <td class="col-num"><?= h(fmt_qty($r['stock_qty'])) ?></td>
              <td class="col-qty">
                <input type="number" name="qty[<?= h((string)$r['sku']) ?>]" value="1"
                       min="1" max="<?= MAX_COPIES ?>" inputmode="numeric">
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <div class="actions">
        <button class="btn btn-primary" type="submit" <?= $rows ? '' : 'disabled' ?>>Tambahkan ke daftar</button>
        <a class="btn btn-ghost" href="index.php">Kembali ke Buat label QR</a>
        <span class="muted small actions-info">
          <?= $selectedCount ?> baris sudah ada di daftar
        </span>
      </div>
    </div>
  </form>

  <?php endif; ?>
</div>
<?php page_end(); ?>
