<?php
declare(strict_types=1);

/** Halaman masuk — memakai akun aplikasi Inventory (diverifikasi read-only). */

require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/layout.php';

if (current_user()) redirect('index.php');

$error = null;
$username = '';
$inventoryMissing = !inventory_exists();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $username = trim((string)($_POST['username'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    $error = login_attempt($username, $password);
    if ($error === null) redirect('index.php');
}

page_start('Masuk', false);
?>
<section class="login-wrap">
  <form class="card login-card" method="post" action="login.php" autocomplete="off">
    <?= csrf_field() ?>
    <h1 class="login-title"><?= h(APP_NAME) ?></h1>
    <p class="muted login-sub">Pembuat label QR untuk SKU — kertas A6, 10 label per lembar.</p>

    <?php if ($inventoryMissing): ?>
      <?= notice_box('Berkas database aplikasi Inventory tidak ditemukan, jadi akun belum bisa diverifikasi. '
          . 'Pastikan aplikasi Inventory masih ada di ruang kerja yang sama.') ?>
    <?php endif; ?>
    <?php if ($error !== null): ?>
      <?= notice_box($error) ?>
    <?php endif; ?>

    <label class="field">
      <span>Nama pengguna</span>
      <input type="text" name="username" value="<?= h($username) ?>" required autofocus
             <?= $inventoryMissing ? 'disabled' : '' ?>>
    </label>
    <label class="field">
      <span>Kata sandi</span>
      <input type="password" name="password" required <?= $inventoryMissing ? 'disabled' : '' ?>>
    </label>

    <button class="btn btn-primary btn-block" type="submit" <?= $inventoryMissing ? 'disabled' : '' ?>>Masuk</button>
    <p class="muted small login-note">Gunakan akun yang sama seperti di aplikasi Inventory.</p>
  </form>
</section>
<?php page_end(); ?>
