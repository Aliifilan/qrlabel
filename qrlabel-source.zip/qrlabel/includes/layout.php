<?php
declare(strict_types=1);

/** Kerangka halaman (shell) aplikasi Label QR SKU — tampilan sengaja polos dan terang. */

function page_start(string $title, bool $with_topbar = true): void
{
    $user = function_exists('current_user') ? current_user() : null;
    echo '<!doctype html>' . "\n";
    echo '<html lang="id">' . "\n<head>\n";
    echo '<meta charset="utf-8">' . "\n";
    echo '<meta name="viewport" content="width=device-width, initial-scale=1">' . "\n";
    echo '<title>' . h($title) . ' — ' . h(APP_NAME) . '</title>' . "\n";
    echo '<link rel="stylesheet" href="assets/app.css">' . "\n";
    echo '</head>' . "\n<body>\n";
    if ($with_topbar) {
        echo '<header class="topbar noprint">' . "\n";
        echo '  <div class="topbar-inner">' . "\n";
        echo '    <a class="brand" href="index.php">' . h(APP_NAME) . '</a>' . "\n";
        echo '    <div class="topbar-right">' . "\n";
        if ($user) {
            echo '      <span class="who">' . h((string)($user['name'] ?: $user['username'])) . '</span>' . "\n";
            echo '      <a class="btn btn-ghost btn-sm" href="logout.php">Keluar</a>' . "\n";
        }
        echo '    </div>' . "\n";
        echo '  </div>' . "\n";
        echo '</header>' . "\n";
    }
    echo '<main class="page">' . "\n";
}

function page_end(): void
{
    echo '</main>' . "\n";
    echo '<script src="assets/app.js"></script>' . "\n";
    echo '</body>' . "\n</html>\n";
}

/** Kotak pesan (galat / info / sukses). */
function notice_box(string $message, string $type = 'error', string $extra_class = ''): string
{
    return '<div class="notice notice-' . h($type) . ($extra_class !== '' ? ' ' . h($extra_class) : '') . '">'
        . h($message) . '</div>';
}
