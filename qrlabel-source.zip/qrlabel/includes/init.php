<?php
declare(strict_types=1);

/**
 * Bootstrap aplikasi Label QR SKU.
 *
 * Aplikasi ini TIDAK punya database sendiri:
 *  - akun pengguna memakai tabel `users` aplikasi Inventory (dibuka READ-ONLY),
 *  - daftar produk untuk tombol "Ambil dari Inventory" juga dibaca READ-ONLY.
 * Jadi aplikasi ini tidak pernah menulis apa pun ke data Inventory.
 */

require_once __DIR__ . '/qr.php';

const APP_NAME = 'Label QR SKU';
const SHEET_COLS = 2;                 // kolom label per lembar A6
const SHEET_ROWS = 5;                 // baris label per lembar A6
const LABELS_PER_SHEET = 10;          // 2 x 5 = 10 label per lembar
const MAX_LABELS = 400;               // batas label per sekali cetak (50 lembar)
const MAX_LIST = 1000;                // batas isi daftar SKU di sesi
const MAX_COPIES = 50;                // salinan per SKU
const QR_ECC = 'M';                   // tingkat koreksi tetap: cocok untuk label produk

/* ------------------------------------------------------------------ */
/* Helper dasar                                                       */
/* ------------------------------------------------------------------ */

function h($s): string
{
    return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8');
}

function redirect(string $url): never
{
    header('Location: ' . $url);
    exit;
}

function session_boot(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) return;
    /* Sebagian server tidak punya folder sesi bawaan PHP — pakai folder sementara bila perlu. */
    $savePath = (string)ini_get('session.save_path');
    if (str_contains($savePath, ';')) {
        $parts = explode(';', $savePath);
        $savePath = (string)end($parts);
    }
    if ($savePath === '' || !is_dir($savePath) || !is_writable($savePath)) {
        $alt = rtrim(sys_get_temp_dir(), '/\\') . '/qrlabel_sessions';
        if (!is_dir($alt)) { @mkdir($alt, 0700, true); }
        if (is_dir($alt) && is_writable($alt)) {
            @chmod($alt, 0700);
            session_save_path($alt);
        }
    }
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'httponly' => true,
        'samesite' => 'Lax',
        'secure' => $https,
    ]);
    session_name('qrl_sess');
    session_start();
}

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(16));
    return (string)$_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . h(csrf_token()) . '">';
}

function csrf_verify(): void
{
    $token = (string)($_POST['csrf'] ?? '');
    if ($token === '' || !hash_equals((string)($_SESSION['csrf'] ?? ''), $token)) {
        http_response_code(419);
        echo '<!doctype html><meta charset="utf-8"><p>Token keamanan tidak cocok. '
            . 'Muat ulang halaman lalu coba lagi.</p>';
        exit;
    }
}

function flash(?string $message = null, string $type = 'ok'): ?array
{
    if ($message !== null) {
        $_SESSION['flash'] = ['msg' => $message, 'type' => $type];
        return null;
    }
    $f = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return $f;
}

/* ------------------------------------------------------------------ */
/* Akses (read-only) ke database aplikasi Inventory                   */
/* ------------------------------------------------------------------ */

function inventory_db_path(): string
{
    $env = getenv('QRLABEL_DB');
    if (is_string($env) && $env !== '') return $env;
    return dirname(__DIR__) . '/../inventory/data.sqlite';
}

function inventory_exists(): bool
{
    return is_file(inventory_db_path());
}

function inv_db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;
    $path = inventory_db_path();
    if (!is_file($path)) {
        throw new RuntimeException('Berkas database aplikasi Inventory tidak ditemukan.');
    }
    /* mode=ro + query_only: mustahil menulis, walau kode keliru. */
    $pdo = new PDO('sqlite:file:' . $path . '?mode=ro');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->exec('PRAGMA query_only = 1');
    $pdo->exec('PRAGMA busy_timeout = 5000');
    return $pdo;
}

function inv_all(string $sql, array $params = []): array
{
    $st = inv_db()->prepare($sql);
    $st->execute($params);
    return $st->fetchAll();
}

function inv_one(string $sql, array $params = [])
{
    $st = inv_db()->prepare($sql);
    $st->execute($params);
    $row = $st->fetch();
    return $row === false ? null : $row;
}

/* ------------------------------------------------------------------ */
/* Pengguna & sesi                                                    */
/* ------------------------------------------------------------------ */

function current_user(): ?array
{
    static $user = null;
    static $loaded = false;
    if ($loaded) return $user;
    $loaded = true;
    $id = $_SESSION['uid'] ?? null;
    if (!$id || !inventory_exists()) return $user = null;
    try {
        $row = inv_one('SELECT id, username, name, role FROM users WHERE id = ? AND active = 1', [(int)$id]);
    } catch (Throwable $e) {
        return $user = null;
    }
    if (!$row) {
        unset($_SESSION['uid']);
        return $user = null;
    }
    return $user = $row;
}

function require_login(): void
{
    if (!current_user()) redirect('login.php');
}

/** Coba masuk memakai akun aplikasi Inventory. Mengembalikan pesan galat atau null. */
function login_attempt(string $username, string $password): ?string
{
    $username = trim($username);
    if ($username === '' || $password === '') return 'Nama pengguna dan kata sandi wajib diisi.';
    if (!inventory_exists()) {
        return 'Database aplikasi Inventory tidak ditemukan, jadi akun belum bisa diverifikasi.';
    }
    try {
        $row = inv_one('SELECT id, username, password_hash, active FROM users WHERE username = ?', [$username]);
    } catch (Throwable $e) {
        return 'Gagal membaca data pengguna aplikasi Inventory.';
    }
    if (!$row || !password_verify($password, (string)$row['password_hash'])) {
        usleep(300000);   // memperlambat percobaan tebak sandi
        return 'Nama pengguna atau kata sandi salah.';
    }
    if ((int)$row['active'] !== 1) {
        return 'Akun ini sedang nonaktif. Hubungi Admin di aplikasi Inventory.';
    }
    session_regenerate_id(true);
    $_SESSION['uid'] = (int)$row['id'];
    return null;
}

/* ------------------------------------------------------------------ */
/* Daftar SKU (draft di sesi)                                         */
/* ------------------------------------------------------------------ */

function list_get(): array
{
    $list = $_SESSION['qrl_list'] ?? [];
    return is_array($list) ? $list : [];
}

function list_set(array $list): void
{
    $_SESSION['qrl_list'] = array_slice(array_values($list), 0, MAX_LIST);
}

function list_add(array $skus): void
{
    $list = list_get();
    foreach ($skus as $sku) {
        if (count($list) >= MAX_LIST) break;
        $list[] = $sku;
    }
    list_set($list);
}

/** Memecah isi kotak teks menjadi daftar SKU (satu per baris / dipisah koma). */
function parse_sku_input(string $text): array
{
    $parts = preg_split('/[\r\n,;\t]+/', $text) ?: [];
    $out = [];
    foreach ($parts as $p) {
        $p = trim($p);
        if ($p === '') continue;
        $out[] = $p;
    }
    return $out;
}

/** Angka jumlah untuk tabel: bilangan bulat tanpa desimal, pecahan tetap "0,75". */
function fmt_qty($value): string
{
    $f = (float)$value;
    if ($f == (int)$f) return (string)(int)$f;
    return rtrim(rtrim(number_format($f, 2, ',', '.'), '0'), ',');
}

/* ------------------------------------------------------------------ */
/* Ukuran QR & tulisan per label                                      */
/* ------------------------------------------------------------------ */

/**
 * Ukuran label per lembar A6 (10 label: 2 kolom x 5 baris).
 *
 * Angka dihitung dari CSS: lembar 105x148 mm, padding kiri/kanan 4 mm, padding sel 1 mm,
 * jadi lebar berguna tiap sel = (105 - 8) / 2 - 2 = 46,5 mm.
 * Tingginya bergantung pada "jarak aman tepi bawah" (LABEL_SAFETY_OPTIONS):
 *   tinggi sel = (148 - 4 - jarak_aman) / 5, dikurangi padding sel 2 mm.
 * Pada pilihan paling longgar (12 mm) tinggi berguna tiap sel = 24,4 mm, dan itulah
 * angka yang dipakai menyusun tabel ukuran di bawah (kasus terburuk).
 */
const LABEL_CELL_W_MM = 46.5;
const LABEL_CELL_H_MM = 24.4;

/**
 * Jarak aman tepi bawah kertas (mm) — bisa dipilih pengguna.
 *
 * KENAPA INI ADA: printer tidak bisa mencetak sampai tepi kertas. Dirumah printer rumahan,
 * area tidak tercetak di tepi bawah bisa 5–12 mm. Dengan 10 label per lembar (5 baris),
 * baris ke-5 sebelumnya hanya berjarak ~6 mm dari tepi bawah sehingga terpotong printer,
 * padahal dengan 8 label (baris ke-4 sebagai baris terakhir) masih aman ~9 mm.
 * Karena itu blok label sengaja digeser ke atas: makin besar jarak aman, makin tinggi
 * posisi semua label di kertas.
 */
const LABEL_SAFETY_OPTIONS = [4, 8, 12];
const LABEL_SAFETY_DEFAULT = 8;

/** SKU lebih panjang dari ini tidak muat dicetak di label A6 10-per-lembar (lihat catatan di bawah). */
const LABEL_SKU_MAX_CHARS = 62;

/**
 * Tabel ukuran: [maks karakter, ukuran QR mm, ukuran huruf pt, maks baris tulisan].
 *
 * - Perkiraan lebar huruf monospace sengaja pesimis (0,75 em; font monospace umum 0,55–0,62 em)
 *   supaya tulisan tidak pernah terpotong walau font di perangkat berbeda dari saat pengujian.
 * - Teks dipecah menjadi baris oleh PHP (label_lines()) dan CSS memakai `white-space: pre`,
 *   jadi jumlah baris TIDAK bergantung pada lebar font perangkat pengguna.
 * - Tinggi terpakai (QR + jarak 0,6 mm + baris x huruf x 1,3) selalu menyisakan >= 2 mm di
 *   dalam sel kasus terburuk (jarak aman 12 mm). JANGAN menambah ukuran di sini tanpa
 *   menjalankan tests/qrl_print_check.js.
 * - Batas 62 karakter: pada huruf 5,5 pt QR-nya masih versi <= 4 (33 modul) sehingga lebar
 *   satu modul >= 0,45 mm pada QR 15 mm — masih aman dipindai kamera HP.
 */
function label_presets(): array
{
    return [
        ['max' => 22, 'qr' => 17.0, 'font' => 7.5, 'wrap' => 22],
        ['max' => 44, 'qr' => 15.0, 'font' => 6.0, 'wrap' => 22],
        ['max' => LABEL_SKU_MAX_CHARS, 'qr' => 15.0, 'font' => 5.5, 'wrap' => 21],
    ];
}

/** Jarak aman tepi bawah yang sah (dipakai juga saat membaca input pengguna). */
function label_safety_valid(int $mm): bool
{
    return in_array($mm, LABEL_SAFETY_OPTIONS, true);
}

/** Memecah SKU menjadi baris-baris tetap supaya jumlah baris tidak bergantung lebar font. */
function label_lines(string $sku, int $wrap): array
{
    if ($wrap < 1) $wrap = 1;
    $lines = [];
    $len = strlen($sku);
    for ($i = 0; $i < $len; $i += $wrap) {
        $lines[] = substr($sku, $i, $wrap);
    }
    return $lines ?: [''];
}

/** Memilih ukuran QR & huruf yang pas untuk satu SKU (yang terpanjang tidak muat). */
function label_fit(string $sku): array
{
    $len = strlen($sku);
    $presets = label_presets();
    foreach ($presets as $p) {
        if ($len <= $p['max']) return $p;
    }
    return $presets[count($presets) - 1];
}

/**
 * Memeriksa daftar SKU sebelum dicetak. Mengembalikan daftar pesan galat
 * (kosong = siap dicetak). TIDAK pernah membuang data masukan pengguna.
 */
function validate_labels(array $skus, int $copies): array
{
    $errors = [];
    if (!$skus) {
        $errors[] = 'Belum ada SKU yang dimasukkan. Tulis satu SKU per baris, atau ambil dari Inventory.';
        return $errors;
    }
    $total = count($skus) * $copies;
    if ($total > MAX_LABELS) {
        $errors[] = 'Terlalu banyak: ' . $total . ' label (batas ' . MAX_LABELS . ' label sekali cetak).';
    }
    $tooLong = [];
    $overChars = [];
    foreach (array_unique($skus) as $sku) {
        try {
            qr_encode($sku, QR_ECC);
        } catch (Throwable $e) {
            $tooLong[] = $sku;
            if (count($tooLong) >= 5) break;
        }
        if (strlen($sku) > LABEL_SKU_MAX_CHARS && count($overChars) < 5) {
            $overChars[] = $sku;
        }
    }
    if ($tooLong) {
        $errors[] = 'SKU berikut terlalu panjang untuk satu QR code: ' . implode(', ', $tooLong) . '.';
    }
    if ($overChars) {
        $errors[] = 'SKU berikut lebih dari ' . LABEL_SKU_MAX_CHARS . ' karakter sehingga tulisannya tidak muat '
            . 'di label A6 (10 label per lembar): ' . implode(', ', $overChars)
            . '. Pakai SKU yang lebih pendek, atau cetak sebagian dulu.';
    }
    return $errors;
}

/** Mengembangkan daftar SKU menjadi daftar label (tiap SKU sebanyak $copies). */
function build_labels(array $skus, int $copies): array
{
    $labels = [];
    foreach ($skus as $sku) {
        for ($i = 0; $i < $copies; $i++) $labels[] = $sku;
    }
    return $labels;
}

/** Memecah label menjadi lembar-lembar berisi LABELS_PER_SHEET label. */
function paginate_labels(array $labels): array
{
    return array_chunk($labels, LABELS_PER_SHEET);
}

/* ------------------------------------------------------------------ */

session_boot();
