<?php
declare(strict_types=1);

/**
 * Pembuat QR Code murni PHP (tanpa ekstensi GD, tanpa library luar).
 *
 * Fitur: mode byte (UTF-8), tingkat koreksi L/M/Q/H, versi 1..40 dipilih otomatis,
 * pemilihan mask terbaik sesuai spesifikasi, keluaran matriks modul + SVG siap cetak.
 *
 * Algoritma mengikuti spesifikasi ISO/IEC 18004. Implementasi ini diverifikasi
 * terhadap pustaka qrcode-generator 1.4.4 (matriks harus identik) dan terhadap
 * hasil pembacaan decoder sungguhan (jsQR) — lihat tests/qrl_encode_check.php
 * dan tests/qrl_scan_check.js. Jangan mengubah urutan penempatan/mask tanpa
 * menjalankan kedua uji tersebut.
 */

require_once __DIR__ . '/qr_tables.php';

/** Bit indikator tingkat koreksi pada format informasi: L=01, M=00, Q=11, H=10. */
const QR_ECC_FORMAT = ['L' => 1, 'M' => 0, 'Q' => 3, 'H' => 2];

/** Kolom tabel QR_RS_BLOCKS untuk tiap tingkat koreksi. */
const QR_ECC_COL = ['L' => 0, 'M' => 1, 'Q' => 2, 'H' => 3];

/** Panjang informasi jumlah karakter (mode byte) menurut versi QR. */
function qr_length_bits(int $version): int
{
    return $version < 10 ? 8 : 16;
}

/** Jumlah codeword data (sebelum ECC) untuk versi & tingkat koreksi tertentu. */
function qr_data_codewords(int $version, string $ecc): int
{
    $total = 0;
    foreach (QR_RS_BLOCKS[$version][$ecc] as $group) {
        $total += $group[0] * $group[2];
    }
    return $total;
}

/** Versi terkecil yang mampu memuat teks sepanjang $len byte pada tingkat koreksi $ecc. */
function qr_pick_version(int $len, string $ecc): int
{
    for ($v = 1; $v <= 40; $v++) {
        $need = 4 + qr_length_bits($v) + $len * 8;
        if ($need <= qr_data_codewords($v, $ecc) * 8) return $v;
    }
    throw new RuntimeException('Teks terlalu panjang untuk satu QR code (maksimal sekitar 2.900 karakter).');
}

/* ------------------------------------------------------------------ */
/* Aritmatika medan Galois GF(256), polinom prima 0x11D               */
/* ------------------------------------------------------------------ */

/** Tabel eksponensial α^n (n boleh negatif / ≥ 255, otomatis diputar). */
function qr_gf_exp(int $n): int
{
    static $exp = null;
    if ($exp === null) {
        $exp = array_fill(0, 256, 0);
        for ($i = 0; $i < 8; $i++) $exp[$i] = 1 << $i;
        for ($i = 8; $i < 256; $i++) {
            $exp[$i] = $exp[$i - 4] ^ $exp[$i - 5] ^ $exp[$i - 6] ^ $exp[$i - 8];
        }
    }
    while ($n < 0) $n += 255;
    while ($n >= 255) $n -= 255;
    return $exp[$n];
}

/** Logaritma basis α (hanya untuk n ≥ 1). */
function qr_gf_log(int $n): int
{
    static $log = null;
    if ($log === null) {
        $log = array_fill(0, 256, 0);
        for ($i = 0; $i < 255; $i++) $log[qr_gf_exp($i)] = $i;
    }
    return $log[$n];
}

function qr_gf_mul(int $a, int $b): int
{
    if ($a === 0 || $b === 0) return 0;
    return qr_gf_exp(qr_gf_log($a) + qr_gf_log($b));
}

/**
 * Polinom generator Reed-Solomon derajat $ecCount, koefisien urut pangkat tertinggi dulu.
 * Hasil: (x - α^0)(x - α^1)...(x - α^(ecCount-1)).
 */
function qr_rs_generator(int $ecCount): array
{
    static $cache = [];
    if (isset($cache[$ecCount])) return $cache[$ecCount];
    $poly = [1];
    for ($i = 0; $i < $ecCount; $i++) {
        $next = array_fill(0, count($poly) + 1, 0);
        $factor = qr_gf_exp($i);
        foreach ($poly as $j => $coef) {
            $next[$j] ^= $coef;
            $next[$j + 1] ^= qr_gf_mul($coef, $factor);
        }
        $poly = $next;
    }
    return $cache[$ecCount] = $poly;
}

/** Menghitung $ecCount codeword koreksi kesalahan untuk satu blok data. */
function qr_rs_remainder(array $data, int $ecCount): array
{
    $gen = qr_rs_generator($ecCount);
    $res = array_merge(array_values($data), array_fill(0, $ecCount, 0));
    $len = count($data);
    for ($i = 0; $i < $len; $i++) {
        $factor = $res[$i];
        if ($factor === 0) continue;
        for ($j = 0; $j <= $ecCount; $j++) {
            if ($gen[$j] === 0) continue;
            $res[$i + $j] ^= qr_gf_exp(qr_gf_log($gen[$j]) + qr_gf_log($factor));
        }
    }
    return array_slice($res, $len, $ecCount);
}

/* ------------------------------------------------------------------ */
/* Aliran bit & codeword                                              */
/* ------------------------------------------------------------------ */

function qr_put_bits(array &$bits, int $value, int $length): void
{
    for ($i = $length - 1; $i >= 0; $i--) {
        $bits[] = ($value >> $i) & 1;
    }
}

/**
 * Menyusun seluruh codeword (data + ECC, sudah diinterleave) untuk satu simbol QR.
 */
function qr_build_codewords(string $text, int $version, string $ecc): array
{
    $blocks = [];
    foreach (QR_RS_BLOCKS[$version][$ecc] as $group) {
        for ($i = 0; $i < $group[0]; $i++) {
            $blocks[] = ['total' => $group[1], 'data' => $group[2]];
        }
    }

    $bits = [];
    qr_put_bits($bits, 0b0100, 4);                          // mode: byte (8 bit)
    qr_put_bits($bits, strlen($text), qr_length_bits($version));
    for ($i = 0, $n = strlen($text); $i < $n; $i++) {
        qr_put_bits($bits, ord($text[$i]), 8);
    }

    $totalData = 0;
    foreach ($blocks as $b) $totalData += $b['data'];
    if (count($bits) > $totalData * 8) {
        throw new RuntimeException('Teks terlalu panjang untuk versi QR yang dipilih.');
    }
    if (count($bits) + 4 <= $totalData * 8) qr_put_bits($bits, 0, 4);
    while (count($bits) % 8 !== 0) $bits[] = 0;
    $pad = [0xEC, 0x11];
    $pi = 0;
    while (true) {
        if (count($bits) >= $totalData * 8) break;
        qr_put_bits($bits, $pad[0], 8);
        if (count($bits) >= $totalData * 8) break;
        qr_put_bits($bits, $pad[1], 8);
        $pi++;
    }

    $buffer = [];
    for ($i = 0, $n = count($bits); $i < $n; $i += 8) {
        $v = 0;
        for ($j = 0; $j < 8; $j++) $v = ($v << 1) | $bits[$i + $j];
        $buffer[] = $v;
    }

    $dcData = [];
    $ecData = [];
    $offset = 0;
    $maxDc = 0;
    $maxEc = 0;
    foreach ($blocks as $b) {
        $dcCount = $b['data'];
        $ecCount = $b['total'] - $dcCount;
        $maxDc = max($maxDc, $dcCount);
        $maxEc = max($maxEc, $ecCount);
        $chunk = array_slice($buffer, $offset, $dcCount);
        $offset += $dcCount;
        $dcData[] = $chunk;
        $ecData[] = qr_rs_remainder($chunk, $ecCount);
    }

    $out = [];
    for ($i = 0; $i < $maxDc; $i++) {
        foreach ($dcData as $chunk) {
            if ($i < count($chunk)) $out[] = $chunk[$i];
        }
    }
    for ($i = 0; $i < $maxEc; $i++) {
        foreach ($ecData as $chunk) {
            if ($i < count($chunk)) $out[] = $chunk[$i];
        }
    }
    return $out;
}

/* ------------------------------------------------------------------ */
/* Informasi format & versi (kode BCH)                                */
/* ------------------------------------------------------------------ */

const QR_G15 = 0b10100110111;
const QR_G18 = 0b1111100100101;
const QR_G15_MASK = 0b101010000010010;

function qr_bch_digit(int $data): int
{
    $digit = 0;
    while ($data !== 0) {
        $digit++;
        $data >>= 1;
    }
    return $digit;
}

function qr_bch_type_info(int $data): int
{
    $d = $data << 10;
    $g15n = qr_bch_digit(QR_G15);
    while (qr_bch_digit($d) - $g15n >= 0) {
        $d ^= (QR_G15 << (qr_bch_digit($d) - $g15n));
    }
    return (($data << 10) | $d) ^ QR_G15_MASK;
}

function qr_bch_type_number(int $data): int
{
    $d = $data << 12;
    $g18n = qr_bch_digit(QR_G18);
    while (qr_bch_digit($d) - $g18n >= 0) {
        $d ^= (QR_G18 << (qr_bch_digit($d) - $g18n));
    }
    return ($data << 12) | $d;
}

/* ------------------------------------------------------------------ */
/* Pola fungsi & penempatan data                                      */
/* ------------------------------------------------------------------ */

function qr_mask_condition(int $pattern, int $i, int $j): bool
{
    switch ($pattern) {
        case 0: return ($i + $j) % 2 === 0;
        case 1: return $i % 2 === 0;
        case 2: return $j % 3 === 0;
        case 3: return ($i + $j) % 3 === 0;
        case 4: return (intdiv($i, 2) + intdiv($j, 3)) % 2 === 0;
        case 5: return (($i * $j) % 2) + (($i * $j) % 3) === 0;
        case 6: return ((($i * $j) % 2) + (($i * $j) % 3)) % 2 === 0;
        case 7: return ((($i * $j) % 3) + (($i + $j) % 2)) % 2 === 0;
    }
    throw new InvalidArgumentException('Pola mask tidak dikenal: ' . $pattern);
}

/** Pola pencari (finder) 7x7 + pemisah (separator) 1 modul di sekelilingnya. */
function qr_place_probe(array &$m, int $size, int $row, int $col): void
{
    for ($r = -1; $r <= 7; $r++) {
        if ($row + $r <= -1 || $size <= $row + $r) continue;
        for ($c = -1; $c <= 7; $c++) {
            if ($col + $c <= -1 || $size <= $col + $c) continue;
            $dark = (0 <= $r && $r <= 6 && ($c === 0 || $c === 6))
                || (0 <= $c && $c <= 6 && ($r === 0 || $r === 6))
                || (2 <= $r && $r <= 4 && 2 <= $c && $c <= 4);
            $m[$row + $r][$col + $c] = $dark;
        }
    }
}

/** Pola waktu (timing) pada baris & kolom ke-6. */
function qr_place_timing(array &$m, int $size): void
{
    for ($r = 8; $r < $size - 8; $r++) {
        if ($m[$r][6] !== null) continue;
        $m[$r][6] = ($r % 2 === 0);
    }
    for ($c = 8; $c < $size - 8; $c++) {
        if ($m[6][$c] !== null) continue;
        $m[6][$c] = ($c % 2 === 0);
    }
}

/** Pola perataan (alignment) 5x5 pada setiap kombinasi posisi versi. */
function qr_place_align(array &$m, int $version): void
{
    $pos = QR_ALIGN_POS[$version] ?? [];
    foreach ($pos as $row) {
        foreach ($pos as $col) {
            if ($m[$row][$col] !== null) continue;
            for ($r = -2; $r <= 2; $r++) {
                for ($c = -2; $c <= 2; $c++) {
                    $dark = ($r === -2 || $r === 2 || $c === -2 || $c === 2 || ($r === 0 && $c === 0));
                    $m[$row + $r][$col + $c] = $dark;
                }
            }
        }
    }
}

/**
 * Menulis informasi format (15 bit) pada dua lokasi.
 * $test = true menulis modul kosong (terang) — dipakai saat menghitung penalti mask,
 * persis seperti pustaka acuan, sehingga pemilihan mask-nya sama.
 */
function qr_place_type_info(array &$m, int $size, string $ecc, int $mask, bool $test): void
{
    $data = (QR_ECC_FORMAT[$ecc] << 3) | $mask;
    $bits = qr_bch_type_info($data);
    for ($i = 0; $i < 15; $i++) {
        $mod = (!$test && ((($bits >> $i) & 1) === 1));
        if ($i < 6) $m[$i][8] = $mod;
        elseif ($i < 8) $m[$i + 1][8] = $mod;
        else $m[$size - 15 + $i][8] = $mod;

        if ($i < 8) $m[8][$size - $i - 1] = $mod;
        elseif ($i < 9) $m[8][15 - $i - 1 + 1] = $mod;
        else $m[8][15 - $i - 1] = $mod;
    }
    $m[$size - 8][8] = !$test;   // modul gelap tetap
}

/** Menulis informasi versi (18 bit) untuk versi ≥ 7. */
function qr_place_type_number(array &$m, int $size, int $version, bool $test): void
{
    $bits = qr_bch_type_number($version);
    for ($i = 0; $i < 18; $i++) {
        $mod = (!$test && ((($bits >> $i) & 1) === 1));
        $m[intdiv($i, 3)][$i % 3 + $size - 11] = $mod;
    }
    for ($i = 0; $i < 18; $i++) {
        $mod = (!$test && ((($bits >> $i) & 1) === 1));
        $m[$i % 3 + $size - 11][intdiv($i, 3)] = $mod;
    }
}

/** Menempatkan codeword secara zig-zag dari kanan bawah, dengan mask diterapkan. */
function qr_map_data(array &$m, int $size, array $codewords, int $mask): void
{
    $inc = -1;
    $row = $size - 1;
    $bitIndex = 7;
    $byteIndex = 0;
    for ($col = $size - 1; $col > 0; $col -= 2) {
        if ($col === 6) $col -= 1;
        while (true) {
            for ($c = 0; $c < 2; $c++) {
                if ($m[$row][$col - $c] === null) {
                    $dark = false;
                    if ($byteIndex < count($codewords)) {
                        $dark = ((($codewords[$byteIndex] >> $bitIndex) & 1) === 1);
                    }
                    if (qr_mask_condition($mask, $row, $col - $c)) $dark = !$dark;
                    $m[$row][$col - $c] = $dark;
                    $bitIndex--;
                    if ($bitIndex === -1) {
                        $byteIndex++;
                        $bitIndex = 7;
                    }
                }
            }
            $row += $inc;
            if ($row < 0 || $size <= $row) {
                $row -= $inc;
                $inc = -$inc;
                break;
            }
        }
    }
}

/**
 * Penalti mask (semakin kecil semakin baik). Aturan 1-4 sesuai spesifikasi.
 */
function qr_lost_point(array $m, int $size): float
{
    $lost = 0.0;

    for ($row = 0; $row < $size; $row++) {
        for ($col = 0; $col < $size; $col++) {
            $same = 0;
            $dark = (bool)$m[$row][$col];
            for ($r = -1; $r <= 1; $r++) {
                if ($row + $r < 0 || $size <= $row + $r) continue;
                for ($c = -1; $c <= 1; $c++) {
                    if ($col + $c < 0 || $size <= $col + $c) continue;
                    if ($r === 0 && $c === 0) continue;
                    if ($dark === (bool)$m[$row + $r][$col + $c]) $same++;
                }
            }
            if ($same > 5) $lost += 3 + $same - 5;
        }
    }

    for ($row = 0; $row < $size - 1; $row++) {
        for ($col = 0; $col < $size - 1; $col++) {
            $count = 0;
            if ($m[$row][$col]) $count++;
            if ($m[$row + 1][$col]) $count++;
            if ($m[$row][$col + 1]) $count++;
            if ($m[$row + 1][$col + 1]) $count++;
            if ($count === 0 || $count === 4) $lost += 3;
        }
    }

    for ($row = 0; $row < $size; $row++) {
        for ($col = 0; $col < $size - 6; $col++) {
            if ($m[$row][$col] && !$m[$row][$col + 1] && $m[$row][$col + 2]
                && $m[$row][$col + 3] && $m[$row][$col + 4] && !$m[$row][$col + 5]
                && $m[$row][$col + 6]) {
                $lost += 40;
            }
        }
    }
    for ($col = 0; $col < $size; $col++) {
        for ($row = 0; $row < $size - 6; $row++) {
            if ($m[$row][$col] && !$m[$row + 1][$col] && $m[$row + 2][$col]
                && $m[$row + 3][$col] && $m[$row + 4][$col] && !$m[$row + 5][$col]
                && $m[$row + 6][$col]) {
                $lost += 40;
            }
        }
    }

    $darkCount = 0;
    for ($row = 0; $row < $size; $row++) {
        for ($col = 0; $col < $size; $col++) {
            if ($m[$row][$col]) $darkCount++;
        }
    }
    $ratio = abs(100 * $darkCount / $size / $size - 50) / 5;
    return $lost + $ratio * 10;
}

/** Membangun satu matriks lengkap untuk mask tertentu ($test = matriks uji penalti). */
function qr_make_impl(int $version, string $ecc, array $codewords, int $mask, bool $test): array
{
    $size = $version * 4 + 17;
    $m = array_fill(0, $size, array_fill(0, $size, null));
    qr_place_probe($m, $size, 0, 0);
    qr_place_probe($m, $size, $size - 7, 0);
    qr_place_probe($m, $size, 0, $size - 7);
    qr_place_align($m, $version);
    qr_place_timing($m, $size);
    qr_place_type_info($m, $size, $ecc, $mask, $test);
    if ($version >= 7) qr_place_type_number($m, $size, $version, $test);
    qr_map_data($m, $size, $codewords, $mask);
    return $m;
}

/* ------------------------------------------------------------------ */
/* API utama                                                          */
/* ------------------------------------------------------------------ */

/**
 * Membuat QR code.
 * @return array{version:int,size:int,mask:int,matrix:array<int,array<int,int>>}
 */
function qr_encode(string $text, string $ecc = 'M', ?int $version = null, ?int $forceMask = null): array
{
    $ecc = strtoupper($ecc);
    if (!isset(QR_ECC_COL[$ecc])) $ecc = 'M';
    if ($text === '') throw new InvalidArgumentException('Isi QR code tidak boleh kosong.');

    if ($version === null) {
        $version = qr_pick_version(strlen($text), $ecc);
    } elseif ($version < 1 || $version > 40) {
        throw new InvalidArgumentException('Versi QR harus antara 1 dan 40.');
    }

    $codewords = qr_build_codewords($text, $version, $ecc);
    $size = $version * 4 + 17;

    if ($forceMask === null) {
        $mask = 0;
        $bestLost = 0.0;
        for ($i = 0; $i < 8; $i++) {
            $lost = qr_lost_point(qr_make_impl($version, $ecc, $codewords, $i, true), $size);
            if ($i === 0 || $bestLost > $lost) {
                $bestLost = $lost;
                $mask = $i;
            }
        }
    } else {
        $mask = $forceMask;
    }

    $m = qr_make_impl($version, $ecc, $codewords, $mask, false);
    $flat = [];
    for ($r = 0; $r < $size; $r++) {
        $row = [];
        for ($c = 0; $c < $size; $c++) $row[] = $m[$r][$c] ? 1 : 0;
        $flat[] = $row;
    }
    return ['version' => $version, 'size' => $size, 'mask' => $mask, 'matrix' => $flat];
}

/**
 * SVG QR code siap cetak. Modul digabung per baris supaya berkasnya ringkas.
 * $attrs = atribut tambahan pada elemen <svg> (harus sudah di-escape pemanggil).
 */
function qr_matrix_svg(array $matrix, int $size, int $quiet = 4, string $attrs = ''): string
{
    $n = $size + $quiet * 2;
    $rects = [];
    for ($r = 0; $r < $size; $r++) {
        $c = 0;
        while ($c < $size) {
            if (!$matrix[$r][$c]) { $c++; continue; }
            $start = $c;
            while ($c < $size && $matrix[$r][$c]) $c++;
            $rects[] = '<rect x="' . ($start + $quiet) . '" y="' . ($r + $quiet)
                . '" width="' . ($c - $start) . '" height="1"/>';
        }
    }
    return '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ' . $n . ' ' . $n
        . '" shape-rendering="crispEdges" role="img" ' . $attrs . '>'
        . '<rect width="' . $n . '" height="' . $n . '" fill="#ffffff"/>'
        . '<g fill="#000000">' . implode('', $rects) . '</g></svg>';
}

/** Jalan pintas: teks → SVG. */
function qr_svg(string $text, string $ecc = 'M', int $quiet = 4, string $attrs = ''): string
{
    $qr = qr_encode_cached($text, $ecc);
    return qr_matrix_svg($qr['matrix'], $qr['size'], $quiet, $attrs);
}

/**
 * Sama seperti qr_encode(), tetapi hasilnya disimpan selama satu permintaan.
 * Berguna saat mencetak banyak label: SKU yang sama (mis. karena "salinan per SKU")
 * hanya dihitung sekali.
 */
function qr_encode_cached(string $text, string $ecc = 'M'): array
{
    static $cache = [];
    if (count($cache) > 600) $cache = [];
    $key = $ecc . "\0" . $text;
    if (!isset($cache[$key])) $cache[$key] = qr_encode($text, $ecc);
    return $cache[$key];
}
