<?php
declare(strict_types=1);

require_once __DIR__ . '/includes/init.php';

$_SESSION = [];
if (session_status() === PHP_SESSION_ACTIVE) {
    session_destroy();
}
redirect('login.php');
