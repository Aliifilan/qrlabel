<?php
declare(strict_types=1);

/**
 * Halaman utama: masukkan daftar SKU → sistem membuat QR code-nya →
 * hasilnya tersusun 10 label per lembar kertas A6, siap dicetak.
 */

require_once __DIR__ . '/includes/init.php';
require_once __DIR__ . '/includes/layout.php';
require_login();

$list = list_get();
$copies = (int)($_SESSION['qrl_copies'] ?? 1);
$cutlines = (bool)($_SESSION['qrl_cut'] ?? true);
$safety = (int)($_SESSION['qrl_safety'] ?? LABEL_SAFETY_DEFAULT);
if (!label_safety_valid($safety)) $safety = LABEL_SAFETY_DEFAULT;
$error = null;
$keepText = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $action = isset($_POST['clear']) ? 'clear' : 'generate';

    if ($action === 'clear') {
        list_set([]);
        $_SESSION['qrl_show'] = false;
        flash('Daftar SKU dikosongkan.');
        redirect('index.php');
    }

    $keepText = (string)($_POST['skus'] ?? '');
    $copies = max(1, min(MAX_COPIES, (int)($_POST['copies'] ?? 1)));
    $cutlines = !empty($_POST['cutlines']);
    $safetyIn = (int)($_POST['safety'] ?? LABEL_SAFETY_DEFAULT);
    $safety = label_safety_valid($safetyIn) ? $safetyIn : LABEL_SAFETY_DEFAULT;

    $parsed = parse_sku_input($keepText);
    $errors = validate_labels($parsed, $copies);
    if ($errors) {
        // Data masukan TIDAK hilang: halaman diulang dengan isi apa adanya + pesan galat.
        $error = implode(' ', $errors);
        $_SESSION['qrl_show'] = false;
        $list = $parsed;
        $copySource = $keepText;
    } else {
        list_set($parsed);
        $_SESSION['qrl_copies'] = $copies;
        $_SESSION['qrl_cut'] = $cutlines;
        $_SESSION['qrl_safety'] = $safety;
        $_SESSION['qrl_show'] = true;
        $unique = count(array_unique($parsed));
        flash(count($parsed) . ' baris SKU (' . $unique . ' SKU unik) → '
            . (count($parsed) * $copies) . ' label siap dicetak.');
        redirect('index.php');
    }
}

$showPreview = !empty($_SESSION['qrl_show']) && $list;
$skusText = $keepText ?? implode("\n", $list);
$flashMsg = flash();

$labels = $showPreview ? build_labels($list, $copies) : [];
$sheets = $showPreview ? paginate_labels($labels) : [];
$sheetCount = count($sheets);

page_start('Buat label QR');
?>
<div class="wrap">

  <div class="page-head noprint">
    <h1>Label QR SKU</h1>
    <p class="muted">Masukkan SKU yang diinginkan, sistem membuat QR code-nya otomatis —
      <strong>10 label per lembar kertas A6</strong> (<?= SHEET_COLS ?> kolom × <?= SHEET_ROWS ?> baris).</p>
  </div>

  <?php if ($flashMsg): ?>
    <?= notice_box((string)$flashMsg['msg'], (string)$flashMsg['type'], 'noprint') ?>
  <?php endif; ?>
  <?php if ($error !== null): ?>
    <?= notice_box($error, 'error', 'noprint') ?>
  <?php endif; ?>
  <?php if (!inventory_exists()): ?>
    <?= notice_box('Daftar produk Inventory tidak bisa dibaca (berkas database tidak ditemukan), '
        . 'tetapi mengetik SKU manual tetap bisa dipakai.', 'warn', 'noprint') ?>
  <?php endif; ?>

  <form class="card form-card noprint" method="post" action="index.php">
    <?= csrf_field() ?>
    <input type="hidden" name="action" value="generate">

    <div class="field">
      <label for="skus"><strong>Daftar SKU</strong>
        <span class="muted small">— satu SKU per baris (boleh juga dipisah koma). Salinan ganda diperbolehkan.</span></label>
      <textarea id="skus" name="skus" rows="10" spellcheck="false"
                placeholder="JK-001&#10;JK-002&#10;BRG-2026-0007"><?= h($skusText) ?></textarea>
      <div class="hint" id="sku-hint"></div>
    </div>

    <div class="form-row">
      <label class="field field-inline">
        <span>Salinan per SKU</span>
        <input type="number" name="copies" id="copies" value="<?= h((string)$copies) ?>" min="1" max="<?= MAX_COPIES ?>">
      </label>
      <label class="check">
        <input type="checkbox" name="cutlines" value="1" <?= $cutlines ? 'checked' : '' ?>>
        <span>Tampilkan garis potong</span>
      </label>
      <label class="field field-inline">
        <span>Jarak aman tepi bawah</span>
        <select name="safety" id="safety">
          <?php foreach (LABEL_SAFETY_OPTIONS as $mm): ?>
            <option value="<?= $mm ?>" <?= $safety === $mm ? 'selected' : '' ?>>
              <?= $mm ?> mm<?= $mm === LABEL_SAFETY_DEFAULT ? ' — disarankan' : ($mm === 4 ? ' — hemat kertas' : ' — printer margin lebar') ?>
            </option>
          <?php endforeach; ?>
        </select>
      </label>
    </div>
    <p class="muted small hint-block">Kalau <strong>baris paling bawah terpotong</strong> saat dicetak,
      naikkan "Jarak aman tepi bawah" (printer tidak bisa mencetak sampai tepi kertas).</p>

    <div class="actions">
      <button class="btn btn-primary" type="submit">Buat QR</button>
      <a class="btn btn-ghost" href="pick.php">Ambil dari Inventory</a>
      <?php if ($list): ?>
        <button class="btn btn-ghost btn-danger" type="submit" name="clear" value="1"
                formnovalidate onclick="return confirm('Kosongkan daftar SKU?')">Kosongkan</button>
      <?php endif; ?>
      <?php if ($list): ?>
        <span class="muted small actions-info"><?= count($list) ?> baris di daftar</span>
      <?php endif; ?>
    </div>
  </form>

  <?php if ($showPreview): ?>
    <section class="result-head noprint">
      <div>
        <h2><?= count($labels) ?> label · <?= $sheetCount ?> lembar A6</h2>
        <p class="muted small">Di dialog cetak pilih ukuran kertas <strong>A6 (105 × 148 mm)</strong> dan skala
          <strong>100%</strong> (jangan "Fit to page") supaya ukuran label tetap presisi.
          Jarak aman tepi bawah saat ini <strong><?= (int)$safety ?> mm</strong>.</p>
      </div>
      <button class="btn btn-primary" type="button" id="btn-print">Cetak</button>
    </section>

    <section class="sheets-scroll">
      <div class="area-cetak">
        <?php foreach ($sheets as $i => $sheetLabels): ?>
          <div class="sheet-wrap">
            <div class="sheet<?= $cutlines ? ' cutlines' : '' ?>" style="--pad-b: <?= (int)$safety ?>mm">
              <?php foreach ($sheetLabels as $sku): ?>
                <?php
                  $qr = qr_encode_cached($sku, QR_ECC);
                  /* Ukuran QR & huruf dihitung dari panjang SKU (label_fit() di includes/init.php),
                     dan teks sudah dipecah menjadi baris tetap oleh label_lines() supaya jumlah
                     barisnya tidak berubah walau font di perangkat pengguna berbeda. */
                  $fit = label_fit($sku);
                  $lines = label_lines($sku, (int)$fit['wrap']);
                ?>
                <div class="label" style="--qr: <?= sprintf('%.2f', $fit['qr']) ?>mm; --fs: <?= sprintf('%.1f', $fit['font']) ?>pt">
                  <div class="qr"><?= qr_matrix_svg($qr['matrix'], $qr['size'], 4, 'data-qr="' . h($sku) . '"') ?></div>
                  <div class="sku"><?= h(implode("\n", $lines)) ?></div>
                </div>
              <?php endforeach; ?>
              <?php for ($empty = count($sheetLabels); $empty < LABELS_PER_SHEET; $empty++): ?>
                <div class="label label-empty"></div>
              <?php endfor; ?>
            </div>
            <p class="sheet-note noprint">Lembar <?= $i + 1 ?> dari <?= $sheetCount ?>
              · <?= count($sheetLabels) ?> label<?= $cutlines ? ' · garis potong aktif' : '' ?>
              · jarak aman bawah <?= (int)$safety ?> mm</p>
          </div>
        <?php endforeach; ?>
      </div>
    </section>
  <?php endif; ?>

</div>
<?php page_end(); ?>
