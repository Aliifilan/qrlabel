/* Label QR SKU — interaksi ringan. Tanpa JavaScript pun semua alur tetap jalan
   (halaman ini hanya menambah kemudahan: hitung label, tombol cetak, pilih semua). */
(function () {
  'use strict';

  /* Jumlah label per lembar A6 — harus sama dengan LABELS_PER_SHEET di includes/init.php. */
  var PER_LEMBAR = 10;

  /* Tombol cetak di halaman hasil */
  var printBtn = document.getElementById('btn-print');
  if (printBtn) {
    printBtn.addEventListener('click', function () { window.print(); });
  }

  /* Petunjuk jumlah label sambil mengetik */
  var ta = document.getElementById('skus');
  var hint = document.getElementById('sku-hint');
  var copiesInput = document.getElementById('copies');
  if (ta && hint) {
    var update = function () {
      var lines = ta.value.split(/[\r\n,;\t]+/).map(function (s) { return s.trim(); })
        .filter(function (s) { return s !== ''; });
      var copies = parseInt((copiesInput && copiesInput.value) || '1', 10);
      if (!(copies > 0)) copies = 1;
      if (lines.length === 0) {
        hint.textContent = '';
        return;
      }
      var unique = {};
      lines.forEach(function (s) { unique[s] = true; });
      var total = lines.length * copies;
      var sheets = Math.ceil(total / PER_LEMBAR);
      hint.textContent = lines.length + ' baris · ' + Object.keys(unique).length + ' SKU unik · '
        + total + ' label = ' + sheets + ' lembar A6';
    };
    ta.addEventListener('input', update);
    if (copiesInput) {
      copiesInput.addEventListener('input', update);
      copiesInput.addEventListener('change', update);
    }
    update();
  }

  /* Halaman Ambil dari Inventory: centang/lepas semua */
  var all = document.getElementById('pick-all');
  var table = document.getElementById('pick-table');
  if (all && table) {
    all.addEventListener('change', function () {
      var boxes = table.querySelectorAll('input[type="checkbox"][name="pick[]"]');
      for (var i = 0; i < boxes.length; i++) boxes[i].checked = all.checked;
    });
  }
})();
